const APP_NAME = "V-Guard";
const DATE = "Date";
const WORK_STATION = "Workstsation";
const WORK_STATION_MODEL = "Model";
const TOTAL_COUNT = "Planned count";
const TOTAL_TIME = "Planned time";
const ACTUAL_COUNT = "Actual count";
const ACTUAL_TIME = "Actual time";


export default APP_NAME;
export {DATE,WORK_STATION,WORK_STATION_MODEL,TOTAL_COUNT,TOTAL_TIME,ACTUAL_COUNT,ACTUAL_TIME}